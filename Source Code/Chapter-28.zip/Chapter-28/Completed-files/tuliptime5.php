<!DOCTYPE html>
<html>
  <head>
    <title>Members' Page</title>
    <meta charset=utf-8>
    <link href="style-3d-gdn.css" rel="stylesheet" type="text/css">
  <style type="text/css">
  p#agenda {margin-left:220px; text-align:left;}
h3 {text-align:center;}
  </style> 
     <!--[if lte IE 8]>
		<script src="html5.js">		
    </script>
		<![endif]-->
    </head>
  <body>
    <div id="wrapper">
      <header>
        <h1>The Spring Garden Club</h1>
      </header>
 <?php include ('includes/hmenu.html'); ?>
 
<div id="content">
<div id="leftcol">
<?php include ('includes/vmenu.html'); ?>
</div>
        <div id="rightcol">
          <p>This is the far right column</p>
        </div>
        <div id="midcol">
          <h2>Members' Page</h2>
         <h3>The Agenda for the Meeting of 
      	  17th December 2016 7.00pm</h3>		    
         		    <p id="agenda">Apologies for absence<br>Minutes of previous 
			meeting<br>Approval of minutes<br>Financial report for 2015<br>
			Approval of accounts<br>Plans for 2017<br>Report of club visit to Chelsea Flower 
			Show <br>Any other business<br>Date of next committee meeting</p>
		</div>	
      
      <footer>
        <p>This is the footer</p>
      </footer>
     <br> 
      </div><!--content div finishes here-->
    </div><!--wrapper div finishes here -->
  </body>
</html>
