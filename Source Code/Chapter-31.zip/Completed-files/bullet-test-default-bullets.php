<!DOCTYPE html>
<html>
  <head>
   	<title>Bullet test</title>
    <meta charset=utf-8>
    <meta name="description" content="Bulbs, seeds and plants for the spring garden">
    <meta name="keywords" content=" bulbs, seeds, plants, spring bulbs, spring garden seeds, spring garden plants">
    <link href="style-3d-gdn.css" rel="stylesheet" type="text/css">
     <style type="text/css">
     .small {font-size:75%; color:black;}
     #midcol-left, #midcol-right {border:1px black solid;}
     /*#midcol-left li, #midcol-right li {padding-left:0; margin-left:-20px;}*/
/*     #midcol-left li, #midcol-right li {padding-left:0; margin-left:-20px; list-style-position:inside; font-size:medium; font-size:130%; text-align:left;}*/

     </style>
     <!--[if lte IE 8]>
		<script src="html5.js">		
    </script>
		<![endif]-->
    </head>
  <body>
    <div id="wrapper">
     <?php include ("header.html"); ?>
 <?php include ("nav.html"); ?>
<!--
      <header>
        <h1>The Spring Garden</h1>
      </header>
 <nav>
          <ul>
            <li class="btn"><a href="spring-bulbs.html" title="Spring garden bulbs">Spring Bulbs</a></li>
            <li class="btn"><a href="spring-seeds.html" title="Spring garden seeds">Spring Seeds</a></li>
            <li class="btn"><a href="spring-plants.html" title="Spring garden plants">Spring Plants</a></li>
            <li class="btn"><a href="index.html" title="Return to Home page">Home Page</a></li>
          </ul>
        </nav>-->
<div id="content">
<div id="leftcol">
 <?php include ("vertnav.html"); ?>
<!--
         <nav id="vertical">
          <ul>
            <li class="vbtn"><a href="#" title="About Us">About Us</a></li>
            <li class="vbtn"><a href="contact.html" title="Contact Us">Contact Us</a></li>
            <li class="vbtn"><a href="#" title="Locate Us">Locate Us</a></li>
            <li class="vbtn"><a href="#" title="Terms and Conditions">Terms</a></li>
          </ul>
        </nav>-->          
</div>
        <div id="rightcol">
          <p>This is the far right column</p>
        </div>
        <div id="midcol">
                    <h2>Spring Garden Bulbs, Seeds and Plants</h2>
            <div id="midcol-left">
            <!--<h2 class="left"><strong>The Joy of Spring</strong></h2>-->
            	<ul>
					<li>
					<p class="left">Spring, the sweet spring, is the year's pleasant king; Then 
			blooms each thing...<br><span class="quote">From "Spring" by 
			Thomas Nash</span></p><br>
					<li> 
					<p class="left">Nothing heralds the arrival of spring better than 
			  a garden full of spring flowers. This web site will help you to 
			  plan your spring flower display and choose the best spring bulbs, 
			  seeds and 
			  plants.</p>
					</li>
					<li>
					<p class="left">View and order spring bulbs, seeds and plants using this web site, or visit the 
			Spring Garden Center at 10 The Street, Townsville.</p>
					</li>
				</ul>
          </div>
            <div id="midcol-right">
			             <!--<h2 class="left"><strong>Poets' Corner</strong></h2>-->
			    <ul>
					<li>
					<p class="left">Mary had a little lamb<br>it walked into some soot, 
					<br>then everywhere 
				that Mary went<br>his sooty foot he put.</p>
					</li>
					<li>
					<p class="left">Scintillate Scintillate 
				globule ethereal<br>How I contemplate your structure and material
					<br>up above the sky so high<br>like a tea tray in the sky</p>
					</li>
				</ul>
				<br> 
			  </div>
          </div>
      </div><!--content div finishes here--> 
      <br class="clear">
        <?php include ("footer.html"); ?>
    </div><!--wrapper div finishes here-->
  </body>
</html>
