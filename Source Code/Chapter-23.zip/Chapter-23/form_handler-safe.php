<?php
/* Feedback Form handler */ 
// set the website owner's email address, eg 
//$mailto = "ownersaddress@example.com" ;
$mailto = "a.j.west@mypostoffice.co.uk" ;
//$mailto = "info@colycomputerhelp.co.uk" ;
$subject = "Feedback from The Spring Garden website" ; 
// list the pages that may have to be displayed, 
$formurl = "http://www.colytonhistory.co.uk/feedback_form.php" ;
$errorurl = "http://www.colytonhistory.co.uk/error.html" ; 
$thankyouurl = "http://www.colytonhistory.co.uk/thankyou.html" ; 
$emailerrurl = "http://www.colytonhistory.co.uk/emailerr.html" ; 
$errorphoneurl = "http://www.colytonhistory.co.uk/phonerror.html" ;
$errorsuggesturl =  "http://www.colytonhistory.co.uk/suggesterror.html" ;
$errorboxurl =  "http://www.colytonhistory.co.uk/boxerror.html" ;

$uself = 0;
// ------- Set the information received from the form as $ values --------------- 
$headersep = (!isset( $uself ) || ($uself == 0)) ? "\r\n" : "\n" ; 
$username = $_POST['username'] ; 
$useremail = $_POST['useremail'] ; 
$userphone = $_POST['userphone']; 
$bulbs = $_POST['bulbs']; 
$seeds = $_POST['seeds']; 
$plants = $_POST['plants'];
$contact=$_POST['contact'];
$message = $_POST['message'] ; 
$http_referrer = getenv( "HTTP_REFERER" ); 
if (!isset($_POST['useremail'])) { 
            header( "Location: $formurl" );
            exit ;}
//Check that all three essential fields are filled in
if (empty($username) || empty($useremail) || empty($userphone)) { 
header( "Location: $errorurl" ); 
		exit ; }
//Check that at least one box has been ticked
if ((!$bulbs and !$seeds and !plants)) { 
header( "Location: $errorboxurl" ); 
		exit ; }
//check that no urls have been inserted in the username text area
if (strpos ($username, '://')||strpos($username, 'www') !==false){
    header( "Location: $errormessageurl" );
            exit ; }
//Check that no urls  have been entered in the phone field
if (strpos ($userphone, '://')||strpos($userphone, 'www') !==false){
    header( "Location: $errorphoneurl" );
            exit ; }
// remove all characters that are not numbers (digits)
$userphone = preg_replace('/\D+/', '', ($userphone));
//check that no urls have been inserted in the message text area
//if (strpos ($message, '://')||strpos($message, 'www') !==false){
//   header( "Location: $errormessageurl" );
//            exit ; }
if ( preg_match( "[\r\n]", $username ) || preg_match( "[\r\n]", $useremail )) { 
          header( "Location: $errorurl" ); 
          exit ; } 
#remove any spaces from beginning and end of email address
$useremail = trim($useremail); 
#Check for permitted email address patterns 
$_name = "/^[-!#$%&\'*+\\.\/0-9=?A-Z^_`{|}~]+"; 
$_host = "([-0-9A-Z]+\.)+"; 
$_tlds = "([0-9A-Z]){2,4}$/i"; 
if(!preg_match($_name."@".$_host.$_tlds,$useremail)) { 
          header( "Location: $emailerrurl" ); 
          exit ; } 
if(!$bulbs) {$bulbs = "No";} 
if(!$seeds) {$seeds = "No";} 
if(!$plants) {$plants = "No";}
if($contact !=null) {$contact = $contact;}
//check that no urls have been inserted in the message text area
if (strpos ($message, '://')||strpos($message, 'www') !==false){
    header( "Location: $errormessageurl" );
            exit ; }
$messageproper = 
          "This message was sent from:\n" . 
          "$http_referrer\n" . 
          "------------------------------------------------------------\n" .
          "Name of sender: $username\n" . 
          "Email of sender: $useremail\n" . 
          "Telephone No: $userphone\n" . 
          "Bulbs brochure?: $bulbs\n" . 
          "Seeds brochure?: $seeds\n" .
          "Plants brochure?: $plants\n" .
          "Contact me by?:$contact\n" .
          "------------------------- MESSAGE -------------------------\n\n" . 
          $message . 
          "\n\n------------------------------------------------------------\n" ; 
mail($mailto, $subject, $messageproper, "From: \"$username\" <$useremail>" ); 
header( "Location: $thankyouurl" ); 
exit ;
?>
