<?php
/* FORM-HANDLER.PHP Feedback Form PHP Script Ver 5.0 */ 
// set the email address for the recipient, this setting sends it to your client for example 
//$mailto = "webmasters-mailaddress@your-isp.com" ;
//$mailto = "a.j.west@mypostoffice.co.uk" ;
//$mailto = "yatesalec@gmail.com" ;
//$mailto = "alec.yates@ukipmail.net" ;
//$mailto = "tony.mcintyre@ukipmail.net" ;
$mailto = "tony.mcintyre@ukipmail.net";
//choose the subject so that you can recognize emails sent from this form 
$subject = "Feedback from tonymcintyre.org website" ; 
/*The next block of code tells the handler where to find the various documents 
associated with it. In this case the documents and the form are all in the same root 
folder.*/
// list the pages to be displayed, 
$formurl = "http://www.tonymcintyre.org/ukip-contact-1.html" ;
$errorurl = "http://www.tonymcintyre.org/error.html" ; 
$thankyouurl = "http://www.tonymcintyre.org/thankyou.html" ; 
$emailerrurl = "http://www.tonymcintyre.org/emailerr.html" ; 
$errorphoneurl = "http://www.tonymcintyre.org/phonerror.html" ;
//$errorsuggesturl = "http://www.ukipdevon.org.uk/suggesterror.html" ;
$errorsuggesturl = "suggesterror.html" ;
$errorboxurl = "http://www.tonymcintyre.org/boxerror.html" ;
$uself = 0;
// ------- Set the information received from the form as $ values --------------- 
$headersep = (!isset( $uself ) || ($uself == 0)) ? "\r\n" : "\n" ; 
/*The following code receives the items from the HTML form and converts them to formats 
 that can be used by the handler, for example, username is converted to $username.*/
$username = $_POST['username'] ; 
$useremail = $_POST['useremail'] ; 
$phone = $_POST['phone']; 
$address1 = $_POST['address1'] ; 
$address2 = $_POST['address2'] ; 
$town = $_POST['town'] ; 
$postcode = $_POST['postcode'] ; 
$suggestion = $_POST['suggestion'] ; 
$http_referrer = getenv( "HTTP_REFERER" ); 
if (!isset($_POST['useremail'])) { 
header( "Location: $formurl" );
exit ;}
//Check that all three essential fields are filled in
if (empty($username) || empty($useremail) || empty($suggestion)) { 
header( "Location: $errorurl" ); 
	exit ; }
//check that no urls have been inserted in the username text area
if (strpos ($username, '://')||strpos($username, 'www') !==false){
header( "Location: $errorsuggesturl" );
exit ; 
}
//check that no urls have been inserted in the address2 text area
if (strpos ($address2, '://')||strpos($address2, 'www') !==false){
header( "Location: $errorsuggesturl" );
exit ; }
//check that no urls have been inserted in the town text area
if (strpos ($town, '://')||strpos($town, 'www') !==false){
header( "Location: $errorsuggesturl" );
exit ; }
//check that no urls have been inserted in the postcode text area
if (strpos ($postcode, '://')||strpos($postcode, 'www') !==false){
header( "Location: $errorsuggesturl" );
exit ; }
//check that no urls have been inserted in the suggestion text area
if (strpos ($suggestion, '://')||strpos($suggestion, 'www') !==false){
header( "Location: $errorsuggesturl" );
exit ; }
if ( ereg( "[\r\n]", $username ) || ereg( "[\r\n]", $useremail )) { 
header( "Location: $errorurl" ); 
exit ; }
# Strip out non-digits
$phone = preg_replace('/\D/', '', $phone);
#remove any spaces from beginning and end of email address
$useremail = trim($useremail); 
#Check for permitted email address patterns 
$_name = "/^[-!#$%&\'*+\\.\/0-9=?A-Z^_`{|}~]+"; 
$_host = "([-0-9A-Z]+\.)+"; 
$_tlds = "([0-9A-Z]){2,4}$/i"; 
if(!preg_match($_name."@".$_host.$_tlds,$useremail)) { 
header( "Location: $emailerrurl" ); 
exit ; } 
if (get_magic_quotes_gpc()) { 
$message = stripslashes( $message ); }
//-- SET UP THE EMAIL�S CONTENT, FORMAT IT, SEND IT. THEN SHOW A THANK YOU PAGE --
$messageproper = 
"This message was sent from:\n" . 
"$http_referrer\n" . 
"------------------------------------------------------------\n" .
"Name of sender: $username\n" . 
"Email of sender: $useremail\n" . 
"Telephone No: $phone\n" .
"Address1: $address1\n" . 
"Address2: $address2\n" .
"Town: $town\n" .
"Post Code: $postcode\n" .
"------------------------- MESSAGE -------------------------\n\n" . 
$suggestion . 
"\n\n------------------------------------------------------------\n" ; 
mail($mailto, $subject, $messageproper, "From: \"$username\" <$useremail>" ); 
header( "Location: $thankyouurl" ); 
exit ;
?>