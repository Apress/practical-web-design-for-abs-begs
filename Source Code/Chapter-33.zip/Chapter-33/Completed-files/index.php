<!DOCTYPE html>
<html>
<head>
    <title>Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset </title>
<meta name="description" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta name="keywords" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="carpet-cleaners.css">
 <style type="text/css">
  li {margin-bottom:10px;}
  #mid-left-col {margin-left:20px; width:305px;}
  #mid-right-col {float:left; margin-left:0; width:60%;}
  #mid-right-col ul {font-size:110%;}
  .btn.tab1 {border-top:3px black solid; border-right:3px black solid; border-bottom:3px black solid; border-left:3px black solid;}
 </style>
</head>
<body>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
  <br> 
 <div id="leftcol">
 <?php include 'includes/vmenu.html'; ?>
 </div>  
 <div id="rightcol">
    <?php include 'includes/infocol.inc'; ?>
 </div>
<div id="midcol">
	<h2><strong>HOME PAGE</strong></h2><br>
<div id="mid-left-col">
      <p class="cntr">
      <img alt="Carpet Picture" height="220" src="images/carpet-pic-300.jpg" width="300"><br>
</div>
     <div id="mid-right-col">
         <ul>
			 <li><strong>We can visit you and conduct a 
			 free, no obligation survey. We will establish the cost and the most suitable type of 
			 carpet cleaning and upholstery cleaning (cloth or leather) for your home, 
			 office, showroom or hotel</strong></li>
			 <li><strong>We test your carpets and upholstery for colour 
			 fastness</strong></li>
			 <li><strong>Oriental Carpet cleaning a speciality</strong></li>
			 <li><strong>Turbo Cleaning for a speedy service</strong></li>
			 <li><strong>Turbo drying of cleaned carpets and upholstery</strong></li>
			 <li><strong>Quality Carpet cleaning and Upholstery cleaning at reasonable cost</strong></li>
			 <li><strong>All our work is properly insured</strong></li>
			 <li><strong>We provide a punctual, friendly, reliable carpet cleaning and upholstery cleaning service</strong></li>
	  	</ul>
  </div><br>
   </div><br><br>
    <footer>
    <?php include 'includes/footer.html'; ?>
  </footer><br></div>
</div><br>
<br class="clear">
</body>
</html>
