<!DOCTYPE html>
<html>
<head>
    <title>Contact Us, Carpet cleaning, Carpet cleaners, Upholstery cleaning,Upholstery cleaners,Devon,Dorset,Somerset</title>
<meta name="description" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta name="keywords" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="carpet-cleaners.css">
<link rel="stylesheet" type="text/css" href="feedback.css" media="screen">
<style type="text/css">
#midcol {margin-left:220px; margin-right:150px;}
h3 {text-align:center; font-weight:bold;}
</style>
</head>
<body>
<a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
     <br> 
 <div id="leftcol">
 <?php include 'includes/vmenu.html'; ?>
 </div>  <br>  
 <div id="rightcol">
    <?php include 'includes/infocol.inc'; ?>
 </div>
 <div id="midcol"><br><br>
<h2>CONTACT TURBO CLEANERS</h2>
		<p><br><span class="red">Warning!</span> Do not enter web addresses into this 
		contact form. If you do, the form 
		<br>will halt and you will have to click the back-button to remove the web 
		address. <br>This protects Clean Living from attack by robot-generated 
		malware.<strong><br>If you tout for SEO business your email will be 
		junked.
  </strong>
     </p>
	<p>&nbsp;</p>
<div>
	<h3>
	Required items <span class="large-red">*</span></h3>
<!--START OF FORM-->
<div id="form">
	<form action="form-handler.php" method="post">
    <div>
    	<label class="label" for="username"><strong>Your Name</strong><span class="large-red">*</span>
	<input id="username" name="username" size="30"></label></div>
<br><br><div>
    <label class="label" for="useremail"><strong>Your Email Address</strong><span class="large-red">*</span>
    <input id="useremail" name="useremail" size="30"></label>
</div><br><br>
<div>
    <label class="label" for="phone"><strong>Your Phone Number </strong><span class="large-red">*</span>
 	<input id="phone" name="phone" size="30"></label>
</div> 
 <br><br>
 <br>
<!--<div>-->
  <h3><strong>If you would like a free, no obligation survey and quotation,<br>
  please supply your address <br>
  </strong>
  </h3>
		<p>&nbsp;</p>
<div><label class="label" for="address1"><strong>House and street</strong>
	<input id="address1" name="address1" size="30"></label></div>
<br><div>
    <label class="label" for="address2"><strong>Address</strong>
    <input id="address2" name="address2" size="30"></label>
</div><br><div>
    <label class="label" for="town"><strong>Town </strong>
	<input id="town" name="town" size="30"></label></div> 
 <br>
 <div>
    <label class="label" for="postcode"><strong>Post Code </strong>
 	<input id="postcode" name="postcode" size="30"></label>
</div>
  <br>
  <div id="sug">
      <br>
   <label for="suggest"><strong><br><br>
	  Please type your message</strong><span class="large-red">*</span></label>
	  <br>
 	  <br>
   <textarea id="suggest" name="suggestion" rows="12" cols="40"></textarea><br><br>
  </div>
  <div id="submit">
  <input id="sb" value="Send your message" title="Send your message" 
  alt="Send your message" type="submit"></div>
 </form>
 </div>
<!--end of form-->
	
</div>

   </div><br><br>
    <footer>
    <?php include 'includes/footer.html'; ?>
  </footer><br></div>
</div><br>
<br class="clear">
</body>
</html>
