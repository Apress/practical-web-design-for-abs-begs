<!DOCTYPE html> 
<html>
<head>
<title>The Spring Garden Club order form</title>
<meta charset="utf-8">
    <link href="style-3d-gdn.css" rel="stylesheet" type="text/css">
    <link href="order.css" rel="stylesheet" type="text/css">    
    	<!--[if lte IE 8]>
		<script src="html5.js"></script>
	<![endif]-->
</head>
<body>
<a id="top"></a>
<div id="wrapper">
<header>
       <h1>The Spring Garden Club</h1>
 </header>
 <div id="midcol">
      <h2>ORDER FORM</h2><br>
	<div id="back-button"><a title="Return to the Home page" href="index.php">Return to Home Page</a>
	</div><br>
<h2 class="screen"><span class="red">Type your details on-screen using your mouse and keyboard.</span> </h2>
	<p class="screen">Data protection: Your name and address will not be stored or shared</p>
	<h3 class="screen">You will find a &quot;print&quot; button at the bottom of the form.</h3>
	<h3>Print two copies, then sign and date them. Keep one copy and post one to: <br>
	The Spring Garden Club, The Garden Centre, 10 The Street, Townsville. <br>
	and enclose a cheque made payable to The Spring Garden Club</h3>
	<h3>Required <span class="large-red">*</span></h3>
<form>
 	<label class="label" for="firstname">Name<span class="large-red">*</span>
	<input id="name" name="name" size="35"></label><br>
 	<label class="label" for="useremail">Your Email Address<span class="large-red">*</span>
	<input id="useremail" name="useremail" size="35"></label><br>
	<label class="label" for="phone">Your Phone Number&nbsp;
	<input id="phone" name="phone" size="35"></label><br>
	<label class="label" for="address1">House and street<span class="large-red">*</span>
	<input id="address1" name="address1" size="35"></label><br>
  	<label class="label" for="address2">Address&nbsp;
	<input id="address2" name="address2" size="35"></label><br>
  	<label class="label" for="town">Town<span class="large-red">*</span>
	<input id="town" name="town" size="35"></label><br>
 	<label class="label" for="postcode">Post Code<span class="large-red">*</span>
	<input id="postcode" name="postcode" size="35"></label>
</form>
<br><br class="clear">
<div id="purchases">
	<h3>When you have printed the form, please write your purchase details<br>in the table below</h3>
<h3>Please send me the following items:</h3>
	<table style="width:770px;">
		<tr class="row1">
			<td style="width: 56px">Qty</td>
			<td style="width: 298px" >Item</td>
			<td style="width: 191px">Price</td>
			<td style="width: 110px">Total</td>
		</tr>
		<tr class="50">
			<td>&nbsp;</td>
			<td>Pack of 10 Tulip bulbs (purple/white)<br></td>
			<td>&pound;4.00&nbsp;+&pound;1.00 p&amp;p</td>
			<td class="td4">&nbsp;</td>
		</tr>
		<tr class="50">
			<td>&nbsp;</td>
			<td>Pack of 20 Crocus bulbs (yellow)<br> </td>
			<td>&pound;4.00 +&pound;1.00 p&amp;p</td>
			<td class="td4">&nbsp;</td>
		</tr>
		<tr class="50">
			<td>&nbsp;</td>
			<td>Pack of 20 Crocus bulbs (purple)<br></td>
			<td>&pound;4.00 +&pound;1.00 p&amp;p</td>
			<td class="td4">&nbsp;</td>
		</tr>
		<tr class="50">
			<td>&nbsp;</td>
			<td>Pack of 20 Snowdrop bulbs<br></td>
			<td>&pound;4.00 +&pound;1.00 p&amp;p</td>
			<td class="td4">&nbsp;</td>
		</tr>
		<tr class="50">
			<td>&nbsp;</td>
			<td>Pack of 10 King Alfred Daffodil bulbs<br></td>
			<td>&pound;5.00 +&pound;1.00 p&amp;p</td>
			<td class="td4">&nbsp;</td>
		</tr>
		<tr class="50">
			<td>&nbsp;</td>
			<td><br></td>
			<td class="total">Total</td>
			<td class="td4">&nbsp;</td>
		</tr>
	</table>
	</div>
<h4>Note: For multiple orders please use the Contact Us button on the home page for a quote for the P&amp;P </h4>
<p><span class="boxstyle">&#9633;</span>Please tick the box to receive emailed newsletters<br>Your email address  will not be shared with any other organization</p>
<p class="sign"><br>
 <br>Signed____________________________&nbsp;Date_________________</p>
 <br>
   <p class="uparrow"><a href="#top">
   <img alt="Go to top" title="Go to top" height="38" src="images/greenup.gif" width="44"></a><br>
	Go to Top</p>
     <footer>
	  <p>This is the footer</p>
     </footer>
  </div>
</div><br class="clear">
<br>
</body>
</html>
