<!DOCTYPE html>
<html>
  <head>
    <title>Wetlands Events</title>
  <meta charset=utf-8> 
  <link href="style-roll-2row.css" rel="stylesheet" type="text/css">
    <style>
     img {margin-top:-15px;}
     table {width:700px; margin-left:220px; border:green 2px solid;padding="3"; border-collapse:collapse; } 
     #content ul {margin-left:335px; width:700px; text-align:left; font-size:110%; font-weight:bold;} 
     #content ul li {margin-bottom:10px;}
     .col1 { width:80px;} 
     .col2 {width:50px;}
     td {border:green 1px solid;  border-collapse:collapse; padding:5px; background:white;}
     .row1 {	text-align:center;}
     span.red {	font-size:large; color:red; font-weight:bold;} 
     p.events {text-align:left; width:700px; margin-left:360px;}
     p.events-2 {text-align:left; width:670px; margin-left:260px;}
   </style> 
    <!--[if lte IE 8]>
		<script src="html5.js">		
    </script>
		<![endif]-->
  </head>
  <body>
     <a id="top"></a>
<div id="wrapper">
    <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include("includes/menu-row1.inc"); ?>
    <?php include("includes/menu-row2.inc"); ?>
    <p>&nbsp;</p>
        <br>
  <div id="content">
	<h2>SUMMER EVENTS 2015</h2>
		<ul>
		  <li>Please wear appropriate clothing and footwear</li>
		  <li>Bring a picnic to the events marked with an asterisk <span class="red">*</span></li>
		  <li>Car share where possible, contact leader if need be</li>
		  <li>At the end of a walk or bird watch, the leader will ask for<br>a donation to the Society's funds.</li>
		</ul>
			<p class="events"><strong>Work Party details:</strong> Donald 
			Duck 01111 22222 <br><strong>Bird Watch details:</strong> Tom 
			Thumb 0111 23456 <br><strong>Walks:</strong> Mike Mouse 01111 33333 <br>
			<strong>County Countryside 
			Service:</strong> 01111 265432 <br><strong>Queries: </strong>about meeting points<strong> </strong>Michael Bird 01111 24689. 
			<br></p>
        <div id="leftcol">
          <!--<p>This is the far left column</p>-->
        </div>
        <div id="rightcol">
          <!--<p>This is the far right column</p>-->
        </div><br>
        <div id="midcol">
			<table>
				<tr class="row1">
					<td class="col1"><strong>Date</strong></td>
					<td class="col2"><strong>Time</strong></td>
					<td class="col3"><strong>Event</strong></td>
				</tr>
				<tr>
					<td>Wed 1st July </td>
					<td>10.30 to 12.30</td>
					<td><strong>Insect Stroll:</strong> Holytree Woods 
					With Michael Bird. Meet at Lofty Tower layby </td>
				</tr>
				<tr>
					<td>Thu. 9th July </td>
					<td>14.00 to 16.30</td>
					<td>
					<strong>Botanical Stroll at Manor House, The Village, </strong>with 
					Michael Bird. Meet at Manor House Farm. Donations to 
					The Manor House Trust.</td>
				</tr>
				<tr>
					<td>Wed. 15th July</td>
					<td>10.30 to 16.00</td>
					<td>
					
					<strong>Dartmoor walk:</strong> 8 miles with Ivan 
					White. Meet at Lower C.P., Hay Tor. Inform Ivan White if 
					attending.<span class="red">*</span> <br><br>
					</td>
				</tr>
				<tr>
					<td>Sat. 18th July</td>
					<td>10.00 to 16.00</td>
					<td><strong>Visit our stand at the Wetlands  
					Festival,</strong> 50 Hardcore House, Townsville</td>
				</tr>				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>Sunday <br>26th July</td>
					<td>6.00pm <br>to 8.00pm</td>
					<td><strong>Train ride - Riverside Bird watch.</strong> 
					Departs from Townsville Train station. Guide: Charles Twitcher.
					<br></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
			</table>
          </div><br>
			<p class="events-2">Other walks and events in the area are arranged by the following 
			organisations<br><br>Subcounty Countryside Service (01111 
			555555);<br>
			<br>Townsville Visitor Centre Trust (www.townsvillevisitorcentretrust.com)<br>Jurassic Coast 
			Trust: (01305 224132; www.jurassiccoast.com)</p>
			<br>
			</div><!--content div finishes here--> 
      <footer>
    <?php include 'includes/footer.html'; ?>
 </footer><br>   
 </div>     
    </div><!--wrapper div finishes here -->
  </body>
</html>

