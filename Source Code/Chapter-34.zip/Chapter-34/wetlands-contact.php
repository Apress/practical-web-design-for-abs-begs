<!DOCTYPE html>
<html>
  <head>
    <title>Home Page</title>
  <meta charset=utf-8> 
    <link href="style-roll-2row.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="feedback.css" media="screen">
   <style>
    img {margin-top:-15px;}
    form {margin-left:200px;width:700px;}
    h3.cntr {text-align:center;} 
  </style> 
    <!--[if lte IE 8]>
		<script src="html5.js">		
        </script>
	<![endif]-->
  </head>
  <body>
    <a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include("includes/menu-row1.inc"); ?>
<?php include("includes/menu-row2.inc"); ?>
<p>&nbsp;</p>
        <br><br>        
        <div id="midcol">
        <h2>CONTACT THE WETLANDS CONSERVATION SOCIETY</h2>
		<p><span class="red">Warning!</span> Do not enter web addresses into this 
		contact form. If you do, the form <br>will halt and you will have to click the back-button to remove the web 
		address. <br>This protects TWCS from attack by robot-generated 
		malware.<strong><br>If you tout for SEO business your email will be 
		junked.
  </strong>
     </p>
<div>
<div id="form">
<!--START OF FORM-->
	<form action="#" method="post">
	<h3 class="cntr">
	Required items <span class="large-red">*</span></h3>
    <div>
    	<label class="label" for="username"><strong>Your Name</strong><span class="large-red">*</span>
	<input id="username" name="username" size="30"></label></div>
<br><br><div>
    <label class="label" for="useremail"><strong>Email Address</strong><span class="large-red">*</span>
    <input id="useremail" name="useremail" size="30"></label>
</div><br><br>
<div>
    <label class="label" for="phone"><strong>Phone Number </strong><span class="large-red">*</span>
 	<input id="phone" name="phone" size="30"></label>
</div> 
 <br>
  <div id="sug">
      <label for="suggest"><strong><br><br>
	  Please type your message</strong><span class="large-red">*</span></label>
	  <br>
 	  <br>
   <textarea id="suggest" name="suggestion" rows="12" cols="40"></textarea><br><br>
  </div>
  <div id="submit">
  <input id="sb" value="Send your message" title="Send your message" 
  alt="Send your message" type="submit"></div><br>
 </form>
 </div>
</div>
</div><!--content div finishes here--> 
   <footer>
    <?php include 'includes/footer.html'; ?>
 </footer><br>   
  </div>    
    </div><!--wrapper div finishes here -->
  </body>
</html>
