<!DOCTYPE html>
<html>
  <head>
    <title>Wetlands Membership</title>
  <meta charset=utf-8> 
    <link href="style-roll-2row.css" rel="stylesheet" type="text/css">
<style>
    img {margin-top:-15px;}
#midcol {margin-left:220px;	width:750px;}   
#midcol-left, #midcol-right {text-align:left; background-color:#CEE1BA; color:black; font-size:110%;}
li.btn-3 {width:250px; text-decoration:none; list-style-type:none; }
#midcolglobal {background-color:#CEE1BA; color:green; width:700px;}
#midcol-left li.btn-3 a  {margin-left:-40px; text-decoration:none;	list-style-type:none; font-size:90%; background:gray; color:white; padding:5px 20px 5px 20px; text-align:center; width:150px; }
#midcol-left li.btn-3 a:link {text-decoration:none; list-style-type:none; color:white; background:gray; }
#midcol-left li.btn-3 a:visited {color:white; }
#midcol-left li.btn-3 a:hover { color:white; background:green;}
#midcol-left li.btn-3 a:active { color:black; }
h3 {font-weight:normal;}
#mid-right-col li.btn {	list-style-type:none; font-size:110%; margin-left:-20px;}
#mid-right-col a:link {text-decoration:none; color:white; }
#mid-right-col a:visited {color:white; }
#mid-right-col a:hover {color:white; }
#mid-right-col a:active {color:black; }
#mid-right-col li.btn {list-style-type:none; font-size:110%; margin-left:-20px;}
#terms {width:700px; margin-left:220px;	text-align:left;}
.clear {clear:both;}	
.chk2 {text-align:left;}
</style>
    <!--[if lte IE 8]>
		<script src="html5.js">		
        </script>
	<![endif]-->
</head>
<body>
    <a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include("includes/menu-row1.inc"); ?>

<?php include("includes/menu-row2.inc"); ?>
<p>&nbsp;</p>
        <br>
        <div id="midcol">
<h2>Join The Wetlands Conservation Society</h2>
<div id="midcol-left">
	<h3><strong>Pay your membership fee<br>with a cheque</strong></h3>
	<ul>
	<li class="btn-3">
	<a href="#" title="Join The Wetlands Conservation Society">Pay by Cheque</a></li>
</ul>
<h3 class="lft"><b>Annual Membership Fees:</b> <br>Individual: &pound;2 <br>
2 persons at same address &pound;3<br>Junior (under 18) &pound;0.5 (Non-voting)&nbsp;</h3>
	<h3 class="lft"><strong>5 year membership fees</strong><br>Individual 5 years: &pound;8 
	<br>2 persons, same 
address 5 years &pound;12<br></h3>
</div>
<div id="midcol-right">
	<h3><strong>Pay your membership fee with<br>PayPal or a credit/debit card</strong></h3>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="XXXXXXXXXXXXX">
<table>
<tr><td><input type="hidden" name="on0" value="UKIP Membership">Select Membership 
	Category</td></tr><tr><td><select name="os0">
	<option value="Standard 1 year">Individual 1 year &pound;2.00 GBP</option>
	<option value="Standard 5 yrs">Individual 5 years &pound;8.00 GBP</option>
	<option value="2 persons same address">2 persons same adddress &pound;3.00 GBP</option>
	<option value="2 persons same address 5yrs">2 persons same adddress &pound;12.00 GBP</option>
	<option value="Junior Under 18">Under 18 &pound;0.50 GBP</option>
</select> </td></tr>
</table><br>
<input type="hidden" name="currency_code" value="GBP">
<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal� the safer, easier way to pay online.">
<img alt="PayPal" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
	<br><br>
</div></div><br class="clear">
<div id="terms">
 <br> 
	<span class="small"><b>Membership is subject to the terms and conditions as follows:<br></b></span>
	By applying for membership of TWCS,&nbsp;
<div class="chk2">
    <input id="chkbox4" name="windows8" value="Yes" type="checkbox" checked="checked">
	  I agree to abide by the <a href="#">TWCS constitution</a> and 
	   the terms and conditions of membership and I give permission to AVDCS 
	to store my details in its databases in accordance with the Data 
	Protection Act. AVDCS will never disclose member's details to other persons or organisations other than 
	TWCS.
          </div><br class="clear"></div><!--content div finishes here--> 
</div><br class="clear"><br class="clear">     
<footer>
    <?php include 'includes/footer.html'; ?>
 </footer><br>   
    </div><!--wrapper div finishes here -->
  </body>
</html>