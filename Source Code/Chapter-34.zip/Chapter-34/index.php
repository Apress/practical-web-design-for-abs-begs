<!DOCTYPE html>
<html>
  <head>
    <title>Home Page</title>
  <meta charset=utf-8> 
    <link href="style-roll-2row.css" rel="stylesheet" type="text/css">
    <style>
      img {margin-top:-15px;}
    </style> 
    <!--[if lte IE 8]>
		<script src="html5.js">		
        </script>
		<![endif]-->
  </head>
<body>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
<div id="mainpanel">
	<?php include("includes/menu-row1.inc"); ?>
	<?php include("includes/menu-row2.inc"); ?>
<p>&nbsp;</p>
  <br>
</div>  
   <br>
    <div id="midcol">
		<p><img alt="Wetlands-1" height="428" src="images/wetlands-2-1100.jpg" width="1100"></p>
    </div>
 <footer>
    <?php include 'includes/footer.html'; ?>
 </footer><br>   
</div><!--wrapper div finishes here -->
</body>
</html>
