<!DOCTYPE html>
<html>
  <head>
    <title>Amenities in the Wetlands nature reserve</title>
  <meta charset=utf-8> 
    <link href="style-roll-2row.css" rel="stylesheet" type="text/css">
    <style>
      img {margin-top:-15px;}
     #midcol-left , #midcol-mid, #midcol-right {width:345px; float:left; font-weight:normal;}
     #midcol-left  {margin-left:60px;}
    </style> 
    <!--[if lte IE 8]>
		<script src="html5.js">		
        </script>
	<![endif]-->
  </head>
  <body>
    <a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include("includes/menu-row1.inc"); ?>
<?php include("includes/menu-row2.inc"); ?>
<p>&nbsp;</p>
        <br>
        <div id="midcol">
          <h2>The Wetlands Amenities</h2>
          <!--Insert four picture in the first column-->  
          <div id="midcol-left">
            <p><img alt="Wetland Visitors' centre" title="Wetland Visitors' centre"height="240" src="images/wetlands-visitor-cntr-320.jpg" width="320">
			  <br>The Visitors' Centre has a range of helpful leaflets and souvenirs.<br><br></p>
            <p><img alt="The car park" title="The car park" height="240" src="images/carpark-320.jpg" width="320">
              <br>The Car park<br><br></p>
            <p><img alt="The classroom" title="The classroom" height="240" src="images/classroom-320.jpg" width="320">
              <br>The Classroom<br><br></p>
            <p><img alt="Plenty of sign posts" title="Plenty of sign posts" height="240" src="images/sign-posts-320.jpg" width="320">
              <br>Plenty of Sign Posts<br><br></p>
          </div>
          <!--Insert four picture in the second column-->  
          <div id="midcol-mid">
            <p><img alt="Paths to Hides" title="Paths to Hides" height="240" src="images/path-hide-320.jpg" width="320">
			    <br>Flat dry paths lead to the various<br>bird hides.<br><br></p>
			<p><img alt="The toilets" title="The toilets" height="244" src="images/toilets-320.jpg" width="320">
			    <br>The Toilets<br><br></p>
			<p><img alt="Inside a bird hide" title="Inside a bird hide" height="240" src="images/Inside-hide-320.jpg" width="320">
              <br>Inside one of the Bird Hides<br><br></p>            
            <p><img alt="Viewing platform" title="Viewing platform" height="239" src="images/platform-320.jpg" width="320">
               <br>One of the Viewing Platforms<br><br></p>
			  </div>
		  <!--Insert four picture in the third column-->  
          <div id="midcol-right">
            <p><img alt="View from Hide" title="View from Hide" height="239" src="images/view-from-hide-320.jpg" width="320">
			  <br>View of a pond from one of the hides.<br>(Overlooks the tram track).<br><br></p>
			<p><img alt="Inside the visitors centre (1)" title="Inside the visitors centre(1)" height="240" src="images/inside-visitors-320-1.jpg" width="320">
			  <br>Inside the Visitors' Centre (1)<br><br></p>
			<p><img alt="Inside the visitors centre (2)" title="Inside the visitors centre (2)" height="240" src="images/inside-visitors-320-2.jpg" width="320">
			  <br>Inside the Visitors' Centre (2)<br><br></p>
            <p><img alt="Star gazing area" title="Star gazing area" height="241" src="images/picnic-320.jpg" width="320">
              <br>Star Gazing Area<br><br></p>
		  </div> 
  </div>
  </div><!--content div finishes here--> 
  <br class="clear">
 <footer>
    <?php include 'includes/footer.html'; ?>
 </footer>
   <br>   
     </div><!--wrapper div finishes here -->
  <br>
  </body>
</html>
