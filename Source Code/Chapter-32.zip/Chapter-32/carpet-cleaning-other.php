<!DOCTYPE html>
<html>
<head>
    <title>Other services, Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset </title>
<meta name="description" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta name="keywords" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="carpet-cleaners.css">
<style type="text/css">
#midcol {margin-left:250px; margin-right:350px; text-align:left;}
h3 {text-align:center; font-weight:bold;}
</style>
</head>
<body><a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include 'includes/hmenu.html'; ?>
  <br>  
 <div id="rightcol">
    <?php include 'includes/infocol.inc'; ?>
 </div>
<div id="midcol"><br>
<h2>OTHER SERVICES</h2>
		<p><strong>
		<img alt="lozenge bullet" height="29" src="images/lozenge.png" width="81">Stain protection</strong>
		<br>Contact us about having your carpets and upholstery protected. Our protection service prevents stains and liquid spillages from 
		penetrating&nbsp;the fibres, making them easy to maintain and clean.

We use a concentrated water based flouro-chemical  carpet and upholstery 
		product that protects fibres from oil, water and dry soil stains. This professional product is specifically designed to be safe, effective and long lasting. 
		Our protection service can be applied to new carpets and upholstery, and to freshly cleaned carpets and upholstery.
</p>
	<p>&nbsp;</p>
	<p><strong>
	<img alt="lozenge bullet" height="29" src="images/lozenge.png" width="81">Difficult 
	fibres</strong></p>
	<p>We can also protect those difficult to clean natural fibre carpets and rugs, 
	for example sea-grass, coir and sisal.
</p>
	<p>&nbsp;</p>
	<p><strong>
	<img alt="lozenge bullet" height="29" src="images/lozenge.png" width="81">Oriental 
	carpets and rugs</strong></p>
	<p>Oriental carpets and rugs cleaned in-situ in your home. </p>
	<p>&nbsp;</p>
	<p><strong>
	<img alt="lozenge bullet" height="29" src="images/lozenge.png" width="81">Leather cleaning</strong> </p>
	<p>&nbsp;</p>
	<p><strong>
	<img alt="lozenge bullet" height="29" src="images/lozenge.png" width="81">Insect treatments</strong></p>
	<p>Insect, moth and flea infestation treatment</p>
<div>
	
 <br>
</div>

   </div><br>
    <footer>
    <?php include 'includes/footer.html'; ?>
  </footer><br></div></div>
<br>

<br class="clear">
</body>
</html>
