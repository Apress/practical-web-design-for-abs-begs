<!DOCTYPE html>
<html>
<head>
    <title>commendations, Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset </title>
<meta name="description" content="commendations,Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta name="keywords" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="carpet-cleaners.css">
 <style type="text/css">
 
  #mid-left-col {margin-left:20px; width:42%; text-align:left;}
  #mid-right-col {float:left; margin-left:0; width:42%; text-align:left;}
   </style>
</head>
<body>
<a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include 'includes/hmenu.html'; ?>
  <br>  
 <div id="rightcol">
    <?php include 'includes/infocol.inc'; ?>
 </div>
<div id="midcol"><br><br>
      <p>&nbsp;</p>
	<h2>COMMENDATIONS</h2><br>
<div id="mid-left-col">
      <p>
    I was very pleased with the prompt, friendly and efficient service. The result 
	was first class; the carpets were thoroughly cleaned and they dried the same 
	day. I am delighted to be able to recommend Clean Living's Carpet Cleaning 
	service.<br>Mrs JMW Colyton Devon<br>
 	  <p class="cntr">
      &nbsp;</p>
	  <p>
	  <br></p></div>
     
     <div id="mid-right-col">
         <p>Clean Living certainly provide a&nbsp; top quality service. Our carpets had 
	grubby patches, but Clean Living soon removed them so that our carpets have 
	never looked so clean. We were extremely pleased with the service and will 
	certainly recommend Clean Living to our friends and neighbours.<br>Mr BW 
	Colyford Devon .</p>
		   </div><br>
   </div><br><br>
    <div id="ftr">
    <?php include 'includes/footer.html'; ?>
  </div><br></div>
</div><br>
<br class="clear">
</body>
</html>
