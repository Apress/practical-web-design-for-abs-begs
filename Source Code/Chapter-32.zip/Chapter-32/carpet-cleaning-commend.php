<!DOCTYPE html>
<html>
<head>
    <title>Commendations, Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset </title>
<meta name="description" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta name="keywords" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="carpet-cleaners.css">
<style type="text/css">
#midcol {margin-left:150px; margin-right:220px; text-align:left;}
h3 {text-align:center; font-weight:bold;}
</style>
</head>
<body>
<a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include 'includes/hmenu.html'; ?>
  <br>  
 <div id="rightcol">
    <?php include 'includes/infocol.inc'; ?>
 </div><div id="midcol"><br><br>
<h2>COMMENDATIONS</h2>
		 <p>&nbsp;</p>
<div id="mid-left-col">		
    I was very pleased with the prompt, friendly and efficient service. The result 
	was first class; the carpets were thoroughly cleaned and they dried the same 
	day. I am delighted to be able to recommend Clean Living's Carpet Cleaning 
	service.<br>Mrs JMW Colyton Devon<br><br><br></div>
<div id="mid-right-col"> 
	Clean Living certainly provide a top quality service. Our carpets had 
	grubby patches, but Clean Living soon removed them so that our carpets have 
	never looked so clean. We were extremely pleased with the service and will 
	certainly recommend Clean Living to our friends and neighbours.<br>Mr BW 
	Colyford Devon .<br>
</div>

   </div><br><br>
    <footer>
    <?php include 'includes/footer.html'; ?>
  </footer><br></div>
</div><br>
<br class="clear">
</body>
</html>
