<!DOCTYPE html>
<html>
<head>
    <title>Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset </title>
<meta name="description" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta name="keywords" content="Carpet cleaning, Carpet cleaners, Upholstery cleaning, Upholstery cleaners, Devon, Dorset, Somerset">
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="carpet-cleaners.css">
 <style type="text/css">
  li {margin-bottom:10px;}
  #mid-left-col {margin-left:0; width:42%;}
  #mid-right-col {float:left; margin-left:0; width:50%;}
  #mid-right-col ul {font-size:110%;}
  .btn.tab1 {border-bottom:4px black solid; border-top:none; border-left:none; border-right:none;}
 </style>
</head>
<body>
<a id="top"></a>
<div id="wrapper">
     <?php include 'includes/header.inc'; ?>
 <div id="mainpanel">
    <?php include 'includes/hmenu.html'; ?>
  <br>  
 <div id="rightcol">
    <?php include 'includes/infocol.inc'; ?>
 </div>
<div id="midcol"><br><br>
      <p>&nbsp;</p>
	<h2><strong>HOME PAGE</strong></h2><br>
<div id="mid-left-col">
      <p class="cntr">
      <img alt="Turbo Carpet Cleaners" height="301" src="images/carpet-pic.jpg" width="411"><br>
	  <p class="lft">
      <br>
	  <br></p></div>
     
     <div id="mid-right-col">
         <ul>
			 <li><strong>We can visit you and conduct a 
			 free, no obligation survey.<br>We will establish the cost and the most suitable type of 
			 carpet cleaning and upholstery cleaning (cloth or leather) for your home, 
			 office, showroom or hotel</strong></li>
			 <li><strong>We test your carpets and upholstery for colour 
			 fastness</strong></li>
			 <li><strong>Oriental Carpet cleaning a speciality</strong></li>
			 <li><strong>Turbo Cleaning for a speedy service</strong></li>
			 <li><strong>Turbo drying of cleaned carpets and upholstery</strong></li>
			 <li><strong>Quality Carpet cleaning and Upholstery cleaning at reasonable cost</strong></li>
			 <li><strong>All our work is properly insured</strong><li><strong>We provide a punctual, 
	  friendly, reliable carpet cleaning and upholstery cleaning service</strong></ul>
		   </div><br>
   </div><br><br>
    <footer>
    <?php include 'includes/footer.html'; ?>
  </footer><br></div>
</div><br>
<?php include ('count-home.php'); ?>
<br class="clear">
</body>
</html>
